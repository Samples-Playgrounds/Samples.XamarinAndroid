# Xamarin.Android Firebase Performance Monitoring Test App
A test Android app to demonstrate that the [Xamarin.Firebase.Perf](https://github.com/xamarin/GooglePlayServicesComponents) package is not reporting on network calls as expected.

See Issue 172: [xamarin.firebase.perf implementation is not showing network call from the app](https://github.com/xamarin/GooglePlayServicesComponents/issues/172)
